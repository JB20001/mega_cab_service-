package model;

public class book {

    String bookid;
    String cusname;
    String cusconno;
    String cusmail;
    String vcat;
    String tripstloc;
    String tripendloc;
    String bookdate;

    public String getBookid() {
        return bookid;
    }

    public void setBookid(String bookid) {
        this.bookid = bookid;
    }

    public String getCusname() {
        return cusname;
    }

    public void setCusname(String cusname) {
        this.cusname = cusname;
    }

    public String getCusconno() {
        return cusconno;
    }

    public void setCusconno(String cusconno) {
        this.cusconno = cusconno;
    }

    public String getCusmail() {
        return cusmail;
    }

    public void setCusmail(String cusmail) {
        this.cusmail = cusmail;
    }

    public String getVcat() {
        return vcat;
    }

    public void setVcat(String vcat) {
        this.vcat = vcat;
    }

    public String getTripstloc() {
        return tripstloc;
    }

    public void setTripstloc(String tripstloc) {
        this.tripstloc = tripstloc;
    }

    public String getTripendloc() {
        return tripendloc;
    }

    public void setTripendloc(String tripendloc) {
        this.tripendloc = tripendloc;
    }

    public String getBookdate() {
        return bookdate;
    }

    public void setBookdate(String bookdate) {
        this.bookdate = bookdate;
    }
}