package model;

public class driver {
public String getDrid() {
		return drid;
	}
	public void setDrid(String drid) {
		this.drid = drid;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getDaddress() {
		return daddress;
	}
	public void setDaddress(String daddress) {
		this.daddress = daddress;
	}
	public int getDtpno() {
		return dtpno;
	}
	public void setDtpno(int dtpno) {
		this.dtpno = dtpno;
	}
	public int getDnic() {
		return dnic;
	}
	public void setDnic(int dnic) {
		this.dnic = dnic;
	}
	public String getDlno() {
		return dlno;
	}
	public void setDlno(String dlno) {
		this.dlno = dlno;
	}
String drid;
String dname;
String daddress;
int dtpno;
int dnic;
String dlno;

}
