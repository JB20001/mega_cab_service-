package model;

public class vehicle {
String vno;
String vcat;
String vmodel;
String vbrand;
String vcolor;
String vchasi;
public String getVno() {
	return vno;
}
public void setVno(String vno) {
	this.vno = vno;
}
public String getVcat() {
	return vcat;
}
public void setVcat(String vcat) {
	this.vcat = vcat;
}
public String getVmodel() {
	return vmodel;
}
public void setVmodel(String vmodel) {
	this.vmodel = vmodel;
}
public String getVbrand() {
	return vbrand;
}
public void setVbrand(String vbrand) {
	this.vbrand = vbrand;
}
public String getVcolor() {
	return vcolor;
}
public void setVcolor(String vcolor) {
	this.vcolor = vcolor;
}
public String getVchasi() {
	return vchasi;
}
public void setVchasi(String vchasi) {
	this.vchasi = vchasi;
}

}
