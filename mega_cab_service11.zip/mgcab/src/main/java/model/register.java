package model;

public class register {
String regno;
String name;
String address;
int nic;
int tpno;
String username;
String pass;


public String getRegno() {
	return regno;
}
public void setRegno(String regno) {
	this.regno = regno;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public int getNic() {
	return nic;
}
public void setNic(int nic) {
	this.nic = nic;
}
public int getTpno() {
	return tpno;
}
public void setTpno(int tpno) {
	this.tpno = tpno;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPass() {
	return pass;
}
public void setPass(String pass) {
	this.pass = pass;
}
}
