package servlet;

import java.sql.Connection;

public class Database {

	public static Connection getConnection() {
		// TODO Auto-generated method stub
		return null;
	}

}
